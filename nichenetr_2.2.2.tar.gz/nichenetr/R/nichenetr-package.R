#' @keywords internal
#' @useDynLib nichenetr, .registration=TRUE
#' @importFrom Rcpp sourceCpp
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
